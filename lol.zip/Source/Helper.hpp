#pragma once

enum struct EntityType //TODO: Move somewhere else so that it used by all objects that need this
{
	PLAYER,
	ENEMY,
	PLAYER_PROJECTILE,
	ENEMY_PROJECTILE
};
